<?php
class Css{
	var $id_css = array();
	var $nom_css;
	var $nom_fichier;
	var $id_type;
	function ListeCss(){
	}
}
?>