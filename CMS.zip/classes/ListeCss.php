<?php
class ListeCss{
	var $arrayCss = array();
	var $nbCss;
	function ListeCss(){
	}
}
?>