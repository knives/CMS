<?php
class Template {
	var $id_template;
	var $nom_template;
	var $nom_fichier;
	function Template(){
	}
}
?>