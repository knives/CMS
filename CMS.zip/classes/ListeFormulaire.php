<?php
class ListeFormulaire{
	var $arrayFormulaire = array();
	var $nbFormulaire ;
	function ListeFormulaire(){
	}
}
?>