<?php
class Liens {
	var $id_lien;
	var $libelle_lien;
	var $action_lien;
	var $target;
	var $method;
	var $id_type;
    var $titre;
    var $position;
    var $title_page;
    
	function Liens(){
	}
}
?>