<?php
class ListeTemplate{
	var $arrayTemplate = array();
	var $nbTemplate;
	function ListeTemplate(){
	}
}
?>