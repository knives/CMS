<?php
class Type {
	var $id_type;
	var $libelle_type;
	var $code_type;
	function Type(){
	}
}
?>