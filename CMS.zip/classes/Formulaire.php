<?php
class Formulaire {
	var $id_formulaire;
	var $nom_formulaire;
	var $action;
	var $target;
	var $method;
	var $id_type;
	function Formulaire(){
	}
}
?>