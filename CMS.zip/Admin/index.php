<script>
window.location='Login.php'
</script>