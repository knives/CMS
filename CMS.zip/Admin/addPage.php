<?php
include_once '../include/librairie.php';
VerifConnexion();
?>
